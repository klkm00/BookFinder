import { useState } from 'react';
import FormLogin from '../login/FormLogin';
import FormRegistro from '../login/FormRegistro';
import './App.css';

// el formulario de registro y la casilla de login seran los componentes principales

function App() {
  const [mostrarRegistro, setMostrarRegistro] = useState(false);

  const cambiarVista = () => {
    setMostrarRegistro(!mostrarRegistro);
  };

  return (
    <div className="app-container">
      {mostrarRegistro ? (
        <>
          <FormRegistro />
          <p style={{ textAlign: 'center' }}>
            ¿Ya tienes cuenta?{' '}
            <button onClick={cambiarVista}>Iniciar sesión</button>
          </p>
        </>
      ) : (
        <>
          <FormLogin />
          <p style={{ textAlign: 'center' }}>
            ¿No tienes cuenta?{' '}
            <button onClick={cambiarVista}>Registrarse</button>
          </p>
        </>
      )}
    </div>
  );
}

export default App;
