import React, {useState} from "react";
import 'boxicons/css/boxicons.min.css';
import './styleLogin.css'; //verificar ruta de estilos
 
const FormLogin = () => {
    const [usuario, setUsuario] = useState('');
    const [constrasena, setContrasena] = useState('');
    const [recordarme, setRecordarme] = useState(false);

    const FormSubmit = (e) => {
        e.preventDefault();
        alert('Inicio de sesión exitoso!');
    };

    return (
    <div className="wrapper">
      <form onSubmit={handleSubmit}>
        <h1 className="centrar">Book Finder</h1>
        <h2 className="centrar">Inicio de sesión</h2>

        <div className="input-box">
          <i className="bx bxs-user"></i>
          <input
            type="text"
            placeholder="Usuario"
            value={usuario}
            onChange={(e) => setUsuario(e.target.value)}
            required
          />
        </div>

        <div className="input-box">
          <i className="bx bxs-lock-alt"></i>
          <input
            type="password"
            placeholder="Contraseña"
            value={contrasena}
            onChange={(e) => setContrasena(e.target.value)}
            required
          />
        </div>

        <div className="remember-forgot">
          <label>
            <input
              type="checkbox"
              checked={recordarme}
              onChange={(e) => setRecordarme(e.target.checked)}
            /> Recuérdame
          </label>
          <a href="../Login/Recuperar.html">¿Olvidaste tu contraseña?</a>
        </div>

        <button type="submit" className="btn">Entrar</button>

        <div className="register-Link">
          <p>¿Aún no te registras? <a href="../Login/Registro.html">Registrarme</a></p>
        </div>
      </form>
    </div>
  );
};

export default FormLogin;

