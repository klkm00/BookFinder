import React, {useState} from "react";
import 'bootstrap/dist/css/bootstrap.min.css';
import './styleLogin.css'; // verificar la ruta de estilos

const FormRegistro = () => {
    const [dataForm, setDataForm] = useState({
        nombre: ' ',
        correo: ' ',
        usuario: ' ',
        contraseña: ' '
    });

    const FormChanges = (e) => {
        const {id, valor} = e.target;
        setDataForm((prev) => ({...prev, [id]: valor}));
    };

    const FormSubmit = (e) => {
        e.preventDesault();
        alert('Registro exitoso!')
        //aqui se agrega el codigo para enviar los datos al backend
    };

    return (
    <div className="modo-claro">
      <div className="container d-flex align-items-center justify-content-center" style={{ minHeight: '100vh' }}>
        <div className="card shadow p-4" style={{ maxWidth: '400px', width: '100%' }}>
          <h2 className="mb-4 text-center">Crear cuenta</h2>
          <form onSubmit={handleSubmit}>
            <div className="mb-3">
              <label htmlFor="nombre" className="form-label">Nombre completo</label>
              <input type="text" className="form-control" id="nombre" value={formData.nombre} onChange={handleChange} required />
            </div>
            <div className="mb-3">
              <label htmlFor="correo" className="form-label">Correo electrónico</label>
              <input type="email" className="form-control" id="correo" value={formData.correo} onChange={handleChange} required />
            </div>
            <div className="mb-3">
              <label htmlFor="usuario" className="form-label">Usuario</label>
              <input type="text" className="form-control" id="usuario" value={formData.usuario} onChange={handleChange} required />
            </div>
            <div className="mb-3">
              <label htmlFor="contrasena" className="form-label">Contraseña</label>
              <input type="password" className="form-control" id="contrasena" value={formData.contrasena} onChange={handleChange} required />
            </div>
            <button type="submit" className="btn btn-primary w-100">Registrarme</button>
          </form>
          <div className="mt-3 text-center">
            <span>¿Ya tienes cuenta? <a href="../Login/indexLogin.html">Inicia sesión</a></span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FormRegistro;