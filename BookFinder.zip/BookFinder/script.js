const dropdown_modo = document.getElementById('dropdown-modo');
const icono_modo = document.getElementById('icono-modo');
const dropdown_claro = document.getElementById('dropdown-claro');
const dropdown_oscuro_menu = document.getElementById('dropdown-oscuro-menu');
const body = document.body;

const bookInput = document.getElementById("bookInput");
const addBookBtn = document.getElementById("addBookBtn");
const bookList = document.getElementById("bookList");

// Evento para el botón de modo claro 
dropdown_claro.addEventListener('click', function() {
    body.classList.add('modo-claro');
    body.classList.remove('modo-oscuro');
    icono_modo.src = '/images/Utilidades/Sol.png';
    dropdown_modo.classList.remove('btn-modo-oscuro');
    dropdown_modo.classList.add('btn-modo-claro');
});

// Evento para el botón de modo oscuro 
dropdown_oscuro_menu.addEventListener('click', function() {
    body.classList.add('modo-oscuro');
    body.classList.remove('modo-claro');
    icono_modo.src = '/images/Utilidades/moon.png';
    dropdown_modo.classList.remove('btn-modo-claro');
    dropdown_modo.classList.add('btn-modo-oscuro');
});

// Funcionalidad para agregar tareas
function agregarLibro() {
    const booktext = bookInput.value;
    if (booktext.trim() === "") {
        alert("Por favor ingrese un Libro");
        return;
    } else {
        const li = document.createElement("li");
        li.textContent = booktext;

        const deletebtn = document.createElement("button");
        deletebtn.textContent = "Eliminar";
        deletebtn.classList.add("delete-btn");
        deletebtn.onclick = () => {
            li.remove();
            saveBook();
        }
        // boton eliminar dentro del libro
        li.appendChild(deletebtn);
        // agregar el libro a la lista Visual
        bookList.appendChild(li);
        // Guardar en localStorage
        saveBook();
        // Limpiar el input
        bookInput.value = "";
    }
}

// Crear un nuevo elemento de lista



// Función para guardar los libros en localStorage
function saveBook() {
    const misLibros = [];
    document.querySelectorAll("#bookList li").forEach(li => {
        misLibros.push({
            text : li.childNodes[0].textContent,
            completed : li.classList.contains("completed")
        });
    });
    localStorage.setItem("misLibros", JSON.stringify(misLibros));
}

// Función para cargar los libros desde localStorage
function loadBooksFromLocalStorage() {
    const misLibros = JSON.parse(localStorage.getItem("misLibros")) || [];
    misLibros.forEach(misLibros => {
        // crear elemento de lista para cada libro guardado
        const li = document.createElement("li");
        li.textContent = misLibros.text;
        if (misLibros.completed) li.classList.add("completed");


        const deletebtn = document.createElement("button");
        deletebtn.textContent = "Eliminar";
        deletebtn.classList.add("delete-btn");
        deletebtn.onclick = () => {
            li.remove();
            saveBook();
        };

        li.addEventListener("click", () => {
            li.classList.toggle("completed");
            saveBook();
        });
        li.appendChild(deletebtn);
        bookList.appendChild(li);
    });
}

bookInput.addEventListener("keypress", function(e) {
    if (e.key === "Enter") {
        agregarLibro();
    }
});

addBookBtn.addEventListener("click", agregarLibro);

// Cargar los libros al iniciar
loadBooksFromLocalStorage();