document.addEventListener("DOMContentLoaded", function() {

  const form = document.querySelector("form");
  const userInput = document.querySelector('input[type="text"]');
  const passInput = document.querySelector('input[type="password"]');

  form.addEventListener("submit", function(e) {
    e.preventDefault();
    const usuario = userInput.value.trim();
    const contrasena = passInput.value.trim();

    // Validación simple: campos no vacíos
    if (usuario === "" || contrasena === "") {
      alert("Por favor, completa ambos campos.");
      return;
    }



    if (usuario === "admin" && contrasena === "1234") {
      window.location.href = "../index.html";
    } else {
      alert("Usuario o contraseña incorrectos.");
    }
  });
});